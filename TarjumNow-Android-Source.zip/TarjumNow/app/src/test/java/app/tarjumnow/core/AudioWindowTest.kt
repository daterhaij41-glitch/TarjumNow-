package app.tarjumnow.core

import app.tarjumnow.capture.AudioWindow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class AudioWindowTest {
    @Test fun createsFirstSixSecondWindowAndThenFourSecondHops() {
        val pipeline = AudioWindow(inputSampleRate = 16_000, stereo = false)
        val oneSecond = ShortArray(16_000) { 4_000 }
        repeat(5) { assertTrue(pipeline.pushPcm16(oneSecond, oneSecond.size).isEmpty()) }
        val sixth = pipeline.pushPcm16(oneSecond, oneSecond.size)
        assertEquals(1, sixth.size)
        assertEquals(96_000, sixth.first().size)
        repeat(3) { pipeline.pushPcm16(oneSecond, oneSecond.size) }
        val next = pipeline.pushPcm16(oneSecond, oneSecond.size)
        assertEquals(1, next.size)
        assertEquals(96_000, next.first().size)
    }
}
