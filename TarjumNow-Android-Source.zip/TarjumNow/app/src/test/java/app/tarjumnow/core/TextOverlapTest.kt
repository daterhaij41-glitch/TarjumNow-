package app.tarjumnow.core

import org.junit.Assert.assertEquals
import org.junit.Test

class TextOverlapTest {
    @Test fun removesRepeatedBoundaryWords() {
        assertEquals("bugün", TextOverlap.removeRepeatedPrefix("merhaba nasılsın", "nasılsın bugün"))
    }
    @Test fun leavesUnrelatedText() {
        assertEquals("iyi akşamlar", TextOverlap.removeRepeatedPrefix("merhaba", "iyi akşamlar"))
    }
}
