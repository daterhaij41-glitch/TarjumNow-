package app.tarjumnow

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import app.tarjumnow.capture.CaptureService
import app.tarjumnow.core.LiveBus
import app.tarjumnow.core.LiveState
import app.tarjumnow.models.ModelRepository
import kotlinx.coroutines.launch

private val Ink = Color(0xFF0B1220)
private val Panel = Color(0xFF121E31)
private val Panel2 = Color(0xFF18263B)
private val Mint = Color(0xFF59D5C5)
private val TextMain = Color(0xFFF2F6FA)
private val TextMuted = Color(0xFF9AAABE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(11,18,32)
        window.navigationBarColor = android.graphics.Color.rgb(11,18,32)
        setContent { TarjumNowApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TarjumNowApp() {
    val context = LocalContext.current
    val activity = context as ComponentActivity
    val state by LiveBus.state.collectAsStateWithLifecycle()
    val repo = remember { ModelRepository(context) }
    var modelLabel by remember { mutableStateOf(repo.modelInfo()) }
    var tab by remember { mutableStateOf(0) }
    var mode by remember { mutableStateOf("internal") }
    var pendingStart by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var info by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    val projectionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(context, CaptureService::class.java).apply {
                action = CaptureService.ACTION_INTERNAL
                putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, result.data)
            }
            ContextCompat.startForegroundService(context, service)
        } else info = "لم توافق على التقاط الصوت الداخلي. يمكنك استخدام الميكروفون بدلًا منه."
    }
    val micPermission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted && pendingStart) {
            pendingStart = false
            if (mode == "mic") startMic(context) else {
                val manager = activity.getSystemService(Activity.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                projectionLauncher.launch(manager.createScreenCaptureIntent())
            }
        } else if (!granted) info = "يجب السماح باستخدام الميكروفون حتى يتمكن التطبيق من تحليل الصوت."
    }
    val filePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch {
            busy = true
            info = "جارٍ استيراد النموذج إلى مساحة التطبيق…"
            runCatching {
                val name = "whisper-" + (uri.lastPathSegment?.substringAfterLast(':') ?: "model.bin")
                repo.importModel(uri, name)
            }.onSuccess {
                modelLabel = repo.modelInfo(); info = "تم حفظ الملف. سيتم التحقق من توافقه عند تحميله لأول مرة."
            }.onFailure { info = "فشل استيراد النموذج: ${it.message}" }
            busy = false
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Mint, secondary = Mint, background = Ink, surface = Panel,
        onBackground = TextMain, onSurface = TextMain
    )) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("ترجم الآن", fontWeight = FontWeight.Bold, fontSize = 21.sp, color = TextMain)
                            Text("تركي إلى عربي • مباشر", fontSize = 12.sp, color = TextMuted)
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Subtitles, null) }, label = { Text("الترجمة") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Memory, null) }, label = { Text("النموذج") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.History, null) }, label = { Text("السجل") })
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                when (tab) {
                    0 -> TranslatePage(
                        state = state,
                        mode = mode,
                        onMode = { mode = it },
                        modelLabel = modelLabel,
                        info = info,
                        busy = busy,
                        onStart = {
                            if (repo.currentModel() == null) { info = "استورد نموذج Whisper من تبويب النموذج أولًا." }
                            else {
                                pendingStart = true
                                micPermission.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        onStop = { context.startService(Intent(context, CaptureService::class.java).setAction(CaptureService.ACTION_STOP)) },
                        onOverlay = {
                            if (!Settings.canDrawOverlays(context)) {
                                context.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")))
                                info = "فعّل الظهور فوق التطبيقات، ثم ارجع إلى التطبيق."
                            } else info = "النافذة العائمة جاهزة؛ ستظهر الترجمة أثناء التشغيل."
                        }
                    )
                    1 -> ModelPage(modelLabel, info, busy, onPick = { filePicker.launch(arrayOf("*/*")) })
                    else -> HistoryPage(state)
                }
                if (info.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(info, color = Mint, fontSize = 12.sp, modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp))
                }
            }
        }
        }
    }
}

private fun startMic(context: android.content.Context) {
    ContextCompat.startForegroundService(context, Intent(context, CaptureService::class.java).setAction(CaptureService.ACTION_MIC))
}

@Composable
private fun TranslatePage(
    state: LiveState, mode: String, onMode: (String) -> Unit, modelLabel: String,
    info: String, busy: Boolean, onStart: () -> Unit, onStop: () -> Unit, onOverlay: () -> Unit
) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Spacer(Modifier.height(2.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatusDot(state.running)
            Text(state.status, color = if (state.running) Mint else TextMuted, fontSize = 13.sp, modifier = Modifier.weight(1f))
            state.processingMs?.let { Text("${it / 1000.0}s", color = TextMuted, fontSize = 12.sp) }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("مصدر الصوت", color = TextMuted, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeButton("الصوت الداخلي", mode == "internal", Modifier.weight(1f)) { onMode("internal") }
                    ModeButton("الميكروفون", mode == "mic", Modifier.weight(1f)) { onMode("mic") }
                }
                Text("النموذج: $modelLabel", color = TextMuted, fontSize = 11.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                    Button(
                        onClick = if (state.running) onStop else onStart,
                        modifier = Modifier.weight(1f).height(52.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = if (state.running) Color(0xFFB94A55) else Mint, contentColor = Ink),
                        shape = RoundedCornerShape(15.dp)
                    ) {
                        Icon(if (state.running) Icons.Default.Stop else Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (state.running) "إيقاف الترجمة" else "ابدأ الترجمة", fontWeight = FontWeight.Bold)
                    }
                    OutlinedButton(onClick = onOverlay, modifier = Modifier.height(52.dp), shape = RoundedCornerShape(15.dp)) {
                        Icon(Icons.Default.PictureInPictureAlt, null)
                    }
                }
            }
        }
        Text("الترجمة الحية", color = TextMain, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Panel2), shape = RoundedCornerShape(19.dp), modifier = Modifier.fillMaxWidth().weight(1f)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("العربية", color = Mint, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(state.translatedText.ifBlank { "ستظهر الترجمة العربية هنا أثناء تشغيل الفيديو…" }, color = TextMain, fontSize = 21.sp, lineHeight = 31.sp)
                Divider(color = Color(0xFF314259))
                Text("النص التركي", color = TextMuted, fontSize = 11.sp)
                Text(state.sourceText.ifBlank { "النص الأصلي يظهر هنا للمراجعة." }, color = TextMuted, fontSize = 15.sp, lineHeight = 23.sp)
            }
        }
        Text("ملاحظة: بعض تطبيقات الفيديو تمنع التقاط الصوت الداخلي. عندها جرّب الميكروفون.", color = TextMuted, fontSize = 11.sp)
        Spacer(Modifier.height(4.dp))
    }
}

@Composable
private fun ModeButton(label: String, selected: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OutlinedButton(onClick = onClick, modifier = modifier.height(43.dp), shape = RoundedCornerShape(12.dp),
        colors = ButtonDefaults.outlinedButtonColors(containerColor = if (selected) Color(0xFF203C4A) else Panel, contentColor = if (selected) Mint else TextMain),
        border = BorderStroke(1.dp, if (selected) Mint else Color(0xFF34445A))) { Text(label, fontSize = 12.sp) }
}

@Composable
private fun StatusDot(active: Boolean) {
    Box(Modifier.size(9.dp).background(if (active) Mint else Color(0xFF78869A), RoundedCornerShape(50)))
}

@Composable
private fun ModelPage(modelLabel: String, info: String, busy: Boolean, onPick: () -> Unit) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Spacer(Modifier.height(8.dp))
        Text("محرك التعرّف", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("يعمل التعرف على الكلام محليًا باستخدام Whisper.cpp. لا يتم إرسال الصوت إلى خادم.", color = TextMuted, fontSize = 13.sp, lineHeight = 20.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Default.Memory, contentDescription = null, tint = Mint, modifier = Modifier.size(30.dp))
                Text("النموذج الحالي", color = TextMuted, fontSize = 12.sp)
                Text(modelLabel, color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Button(onClick = onPick, enabled = !busy, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(13.dp)) {
                    if (busy) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp) else Icon(Icons.Default.FileOpen, null)
                    Spacer(Modifier.width(7.dp)); Text("استيراد ملف نموذج Whisper")
                }
            }
        }
        Card(colors = CardDefaults.cardColors(containerColor = Panel2), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("أي نموذج أختار؟", color = Mint, fontWeight = FontWeight.Bold)
                Text("• Tiny أو Base: أخف على الهاتف، لكن قد تقل الدقة.\n• Small: توازن محتمل بين الدقة والسرعة.\n• Large-v3: يحتاج ذاكرة ومعالجة كبيرة، وقد يكون بطيئًا على Helio G37.", color = TextMain, fontSize = 13.sp, lineHeight = 21.sp)
                Text("لا نثبت بصمة SHA واحدة على كل النماذج؛ سيتم اختبار تحميل النموذج فعليًا عند بدء التشغيل.", color = TextMuted, fontSize = 11.sp)
            }
        }
        Text("لا تضع النموذج داخل APK؛ استورده من ملف الهاتف لتبقى الحزمة صغيرة.", color = TextMuted, fontSize = 12.sp)
    }
}

@Composable
private fun HistoryPage(state: LiveState) {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(5.dp))
        Text("الجمل الأخيرة", color = TextMain, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("يحتفظ هذا الإصدار بآخر الجمل في الذاكرة أثناء الجلسة الحالية.", color = TextMuted, fontSize = 12.sp)
        if (state.lines.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("لا توجد جمل بعد. ابدأ جلسة ترجمة أولًا.", color = TextMuted, textAlign = TextAlign.Center) }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(state.lines.reversed(), key = { it.id }) { line ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
                        Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(line.translated, color = TextMain, fontSize = 17.sp, lineHeight = 24.sp)
                            Text(line.source, color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)
                        }
                    }
                }
            }
        }
    }
}
