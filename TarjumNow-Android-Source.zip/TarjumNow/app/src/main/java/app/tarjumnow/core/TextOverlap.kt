package app.tarjumnow.core

/** Removes the repeated word prefix caused by overlapping audio windows. */
object TextOverlap {
    fun removeRepeatedPrefix(previous: String, current: String, maxWords: Int = 14): String {
        val a = previous.trim().split(Regex("\\s+")).filter { it.isNotBlank() }.takeLast(maxWords)
        val b = current.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (a.isEmpty() || b.isEmpty()) return current.trim()
        val limit = minOf(a.size, b.size)
        for (count in limit downTo 1) {
            val left = a.takeLast(count).joinToString(" ") { normalize(it) }
            val right = b.take(count).joinToString(" ") { normalize(it) }
            if (left == right) return b.drop(count).joinToString(" ").trim()
        }
        return current.trim()
    }

    private fun normalize(word: String): String = word.lowercase().trim { !it.isLetterOrDigit() }
}
