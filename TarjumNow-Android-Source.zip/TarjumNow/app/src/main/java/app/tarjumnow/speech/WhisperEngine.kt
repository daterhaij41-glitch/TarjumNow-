package app.tarjumnow.speech

import com.whispercpp.whisper.WhisperContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class WhisperEngine(modelFile: File) {
    private val context: WhisperContext = WhisperContext.createContextFromFile(modelFile.absolutePath)

    suspend fun transcribe(audio16kMono: FloatArray): String = withContext(Dispatchers.Default) {
        // Native JNI is patched during CI to force language="tr" and disable realtime console output.
        context.transcribeData(audio16kMono, printTimestamp = false).trim()
    }

    suspend fun close() { context.release() }
}
