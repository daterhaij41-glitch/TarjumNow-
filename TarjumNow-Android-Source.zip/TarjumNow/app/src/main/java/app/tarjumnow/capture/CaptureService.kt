package app.tarjumnow.capture

import android.Manifest
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import app.tarjumnow.MainActivity
import app.tarjumnow.core.LiveBus
import app.tarjumnow.core.TextOverlap
import app.tarjumnow.models.ModelRepository
import app.tarjumnow.speech.WhisperEngine
import app.tarjumnow.translation.OfflineTranslator
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    companion object {
        const val ACTION_MIC = "app.tarjumnow.action.MIC"
        const val ACTION_INTERNAL = "app.tarjumnow.action.INTERNAL"
        const val ACTION_STOP = "app.tarjumnow.action.STOP"
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val CHANNEL_ID = "tarjumnow_capture"
        private const val NOTIFICATION_ID = 41
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val running = AtomicBoolean(false)
    private var recorder: AudioRecord? = null
    private var projection: MediaProjection? = null
    private var overlay: OverlayWindow? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        overlay = OverlayWindow(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val command = intent ?: return START_NOT_STICKY
        when (command.action) {
            ACTION_STOP -> stopSession()
            ACTION_MIC, ACTION_INTERNAL -> {
                if (!running.compareAndSet(false, true)) {
                    LiveBus.update { it.copy(status = "جلسة ترجمة قيد التشغيل بالفعل") }
                    return START_NOT_STICKY
                }
                val notification = buildNotification("يتم تجهيز جلسة الترجمة")
                if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIFICATION_ID, notification, foregroundType(command.action))
                else startForeground(NOTIFICATION_ID, notification)
                scope.launch { startSession(command) }
            }
        }
        return START_NOT_STICKY
    }

    private fun foregroundType(action: String?): Int {
        if (Build.VERSION.SDK_INT >= 29) {
            var type = 0
            if (action == ACTION_MIC && Build.VERSION.SDK_INT >= 30) type = type or android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            if (action == ACTION_INTERNAL) type = type or android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            return type
        }
        return 0
    }

    private suspend fun startSession(intent: Intent) {
        try {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                throw IllegalStateException("يلزم السماح باستخدام الميكروفون في إعدادات Android")
            }
            val model = ModelRepository(this).currentModel() ?: throw IllegalStateException("استورد نموذج Whisper أولًا من شاشة النماذج")
            LiveBus.update { it.copy(running = true, status = "تحميل نموذج التعرف…", mode = if (intent.action == ACTION_MIC) "mic" else "internal") }
            val engine = try {
                withContext(Dispatchers.Default) { WhisperEngine(model) }
            } catch (e: OutOfMemoryError) {
                throw IllegalStateException("النموذج أكبر من الذاكرة المتاحة حاليًا. جرّب Whisper Base أو Small بدل Large-v3.")
            }
            val translator = OfflineTranslator()
            try {
                LiveBus.update { it.copy(status = "تجهيز حزمة الترجمة العربية والتركية…") }
                translator.prepare()
                val inputRate: Int
                val isStereo: Boolean
                recorder = if (intent.action == ACTION_INTERNAL) {
                    if (Build.VERSION.SDK_INT < 29) throw IllegalStateException("التقاط الصوت الداخلي يحتاج Android 10 أو أحدث")
                    val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                    val data = getProjectionIntent(intent) ?: throw IllegalStateException("إذن التقاط الصوت الداخلي مفقود")
                    if (resultCode != Activity.RESULT_OK) throw IllegalStateException("لم تمنح إذن التقاط الصوت الداخلي")
                    val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    projection = manager.getMediaProjection(resultCode, data)
                    projection?.registerCallback(object : MediaProjection.Callback() {
                        override fun onStop() {
                            running.set(false)
                            try { recorder?.stop() } catch (_: Exception) {}
                            LiveBus.update { it.copy(running = false, status = "أوقف Android التقاط الصوت الداخلي") }
                        }
                    }, android.os.Handler(mainLooper))
                    val captureConfig = AudioPlaybackCaptureConfiguration.Builder(requireNotNull(projection))
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                        .build()
                    inputRate = 48_000
                    isStereo = true
                    val format = AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(inputRate)
                        .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                        .build()
                    val min = AudioRecord.getMinBufferSize(inputRate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                    AudioRecord.Builder().setAudioFormat(format).setBufferSizeInBytes((min * 2).coerceAtLeast(48_000))
                        .setAudioPlaybackCaptureConfig(captureConfig).build()
                } else {
                    inputRate = 16_000
                    isStereo = false
                    val format = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(inputRate).setChannelMask(AudioFormat.CHANNEL_IN_MONO).build()
                    val min = AudioRecord.getMinBufferSize(inputRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                    AudioRecord.Builder().setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                        .setAudioFormat(format).setBufferSizeInBytes((min * 2).coerceAtLeast(16_000)).build()
                }
                val record = requireNotNull(recorder)
                if (record.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("تعذّر تشغيل مصدر الصوت. جرّب وضع الميكروفون.")
                record.startRecording()
                LiveBus.update { it.copy(status = if (isStereo) "نستمع إلى الصوت الداخلي" else "نستمع إلى الميكروفون") }
                startCaptureAndTranscription(record, inputRate, isStereo, engine, translator)
            } finally {
                try { recorder?.stop() } catch (_: Exception) {}
                recorder?.release(); recorder = null
                try { engine.close() } catch (_: Exception) {}
                translator.close()
                try { projection?.stop() } catch (_: Exception) {}
                projection = null
            }
        } catch (e: Exception) {
            LiveBus.update { it.copy(running = false, status = "تعذّر التشغيل: ${e.message ?: "خطأ غير معروف"}") }
        } finally {
            running.set(false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private suspend fun startCaptureAndTranscription(
        record: AudioRecord,
        sampleRate: Int,
        stereo: Boolean,
        engine: WhisperEngine,
        translator: OfflineTranslator
    ) = coroutineScope {
        val queue = Channel<FloatArray>(capacity = 1, onBufferOverflow = kotlinx.coroutines.channels.BufferOverflow.DROP_OLDEST)
        val worker = launch(Dispatchers.IO) {
            var lastSource = ""
            for (window in queue) {
                val start = System.currentTimeMillis()
                try {
                    val raw = engine.transcribe(window)
                    val fresh = TextOverlap.removeRepeatedPrefix(lastSource, raw)
                    if (fresh.isNotBlank()) {
                        val arabic = translator.translate(fresh)
                        val elapsed = System.currentTimeMillis() - start
                        LiveBus.addLine(fresh, arabic, elapsed)
                        overlay?.show(arabic)
                        lastSource = (lastSource + " " + fresh).takeLast(600)
                    }
                } catch (e: Exception) {
                    LiveBus.update { it.copy(status = "خطأ أثناء التعرف أو الترجمة: ${e.message ?: ""}") }
                }
            }
        }
        val pipeline = AudioWindow(sampleRate, stereo)
        val buffer = ShortArray(if (stereo) 9_600 else 1_600)
        var quietChunks = 0
        try {
            while (isActive && running.get()) {
                val count = record.read(buffer, 0, buffer.size, AudioRecord.READ_BLOCKING)
                if (count > 0) {
                    var sum = 0L
                    for (i in 0 until count) sum += kotlin.math.abs(buffer[i].toInt())
                    val averageLevel = sum.toDouble() / count
                    quietChunks = if (averageLevel < 35.0) quietChunks + 1 else 0
                    if (stereo && quietChunks == 100) {
                        LiveBus.update { it.copy(status = "لا يصل صوت داخلي؛ قد يمنع التطبيق المصدر التسجيل. جرّب الميكروفون.") }
                    }
                    pipeline.pushPcm16(buffer, count).forEach { queue.trySend(it) }
                }
                else if (count < 0 && running.get()) throw IllegalStateException("تعذّرت قراءة الصوت (AudioRecord: $count)")
            }
        } finally {
            queue.close()
            worker.cancelAndJoin()
        }
    }

    @Suppress("DEPRECATION")
    private fun getProjectionIntent(intent: Intent): Intent? = intent.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent

    private fun stopSession() {
        running.set(false)
        try { recorder?.stop() } catch (_: Exception) {}
        overlay?.hide()
        LiveBus.update { it.copy(running = false, status = "تم إيقاف الترجمة") }
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        running.set(false)
        try { recorder?.stop() } catch (_: Exception) {}
        recorder?.release(); recorder = null
        overlay?.hide()
        scope.cancel()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "الترجمة المباشرة", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(message: String): Notification {
        val open = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(this, 1, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val stop = Intent(this, CaptureService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(this, 2, stop, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("ترجم الآن")
            .setContentText(message)
            .setContentIntent(pending)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف", stopPending)
            .setOngoing(true)
            .build()
    }
}
