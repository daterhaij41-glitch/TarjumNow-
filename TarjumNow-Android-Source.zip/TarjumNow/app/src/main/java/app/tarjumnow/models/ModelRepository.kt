package app.tarjumnow.models

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class ModelRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("model_store", Context.MODE_PRIVATE)
    private val modelDir = File(context.filesDir, "speech-models").apply { mkdirs() }

    fun currentModel(): File? = prefs.getString("active_model", null)?.let { File(it) }?.takeIf { it.isFile && it.length() > 10_000_000L }

    suspend fun importModel(uri: Uri, displayName: String): File = withContext(Dispatchers.IO) {
        val safeName = displayName.substringAfterLast('/').replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "whisper-model.bin" }
        val destination = File(modelDir, safeName)
        val temp = File(modelDir, "$safeName.partial")
        context.contentResolver.openInputStream(uri).use { input ->
            requireNotNull(input) { "تعذّر فتح الملف المختار" }
            temp.outputStream().buffered().use { output -> input.copyTo(output, 1024 * 1024) }
        }
        require(temp.length() > 10_000_000L) { "الملف أصغر من المتوقع، لا يبدو أنه نموذج Whisper" }
        require(temp.length() < 3_500_000_000L) { "حجم النموذج أكبر من الحد المدعوم في هذا الإصدار" }
        if (destination.exists()) destination.delete()
        check(temp.renameTo(destination)) { "تعذّر حفظ النموذج في مساحة التطبيق" }
        prefs.edit().putString("active_model", destination.absolutePath).apply()
        destination
    }

    fun modelInfo(): String = currentModel()?.let { "${it.name} • ${it.length() / (1024 * 1024)} MB" } ?: "لا يوجد نموذج مستورد"
}
