package app.tarjumnow.capture

import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import android.os.Build

class OverlayWindow(private val context: Context) {
    private val manager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var view: TextView? = null

    fun show(text: String) {
        if (!android.provider.Settings.canDrawOverlays(context)) return
        val existing = view
        if (existing != null) { existing.text = text; return }
        val v = TextView(context).apply {
            this.text = text
            textSize = 18f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            textDirection = TextView.TEXT_DIRECTION_FIRST_STRONG_RTL
            typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(28, 18, 28, 18)
            background = GradientDrawable().apply {
                setColor(0xE6101829.toInt())
                cornerRadius = 24f
                setStroke(2, 0xFF52C9BB.toInt())
            }
        }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = 110 }
        try { manager.addView(v, params); view = v } catch (_: Exception) { view = null }
    }

    fun hide() {
        view?.let { try { manager.removeView(it) } catch (_: Exception) {} }
        view = null
    }
}
