package app.tarjumnow.capture

import kotlin.math.abs

/** Converts captured PCM16 to mono 16 kHz and emits 6 s windows every 4 s. */
class AudioWindow(private val inputSampleRate: Int, private val stereo: Boolean) {
    private val windowSamples = 16_000 * 6
    private val hopSamples = 16_000 * 4
    private val pending = ArrayList<Float>(windowSamples * 2)

    fun pushPcm16(samples: ShortArray, count: Int): List<FloatArray> {
        if (count <= 0) return emptyList()
        val mono = if (stereo) downmixAndResample(samples, count) else resampleMono(samples, count)
        pending.addAll(mono.asList())
        val result = ArrayList<FloatArray>()
        while (pending.size >= windowSamples) {
            val window = FloatArray(windowSamples) { pending[it] }
            val energy = window.sumOf { abs(it.toDouble()) } / window.size
            if (energy > 0.0018) result.add(window)
            val drop = minOf(hopSamples, pending.size)
            pending.subList(0, drop).clear()
            // The retained two seconds create a deliberate overlap with the next window.
            if (pending.size < windowSamples) break
        }
        return result
    }

    private fun downmixAndResample(input: ShortArray, count: Int): FloatArray {
        val frames = count / 2
        val output = FloatArray((frames * 16_000) / inputSampleRate + 1)
        var out = 0
        var frame = 0
        val step = inputSampleRate / 16_000
        while (frame + step < frames && out < output.size) {
            var sum = 0f
            var n = 0
            for (k in 0 until step) {
                val idx = (frame + k) * 2
                sum += (input[idx].toFloat() + input[idx + 1].toFloat()) / 65536f
                n++
            }
            output[out++] = sum / n
            frame += step
        }
        return output.copyOf(out)
    }

    private fun resampleMono(input: ShortArray, count: Int): FloatArray {
        if (inputSampleRate == 16_000) return FloatArray(count) { input[it] / 32768f }
        val step = (inputSampleRate / 16_000).coerceAtLeast(1)
        val size = (count + step - 1) / step
        val out = FloatArray(size)
        var j = 0
        var i = 0
        while (i < count && j < size) { out[j++] = input[i] / 32768f; i += step }
        return out.copyOf(j)
    }
}
