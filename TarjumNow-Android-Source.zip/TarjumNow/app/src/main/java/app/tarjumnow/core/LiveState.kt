package app.tarjumnow.core

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class SubtitleLine(
    val id: Long,
    val source: String,
    val translated: String,
    val createdAt: Long = System.currentTimeMillis()
)

data class LiveState(
    val running: Boolean = false,
    val mode: String = "internal",
    val status: String = "جاهز للبدء",
    val sourceText: String = "",
    val translatedText: String = "",
    val processingMs: Long? = null,
    val lines: List<SubtitleLine> = emptyList()
)

object LiveBus {
    private val mutable = MutableStateFlow(LiveState())
    val state: StateFlow<LiveState> = mutable.asStateFlow()

    fun set(value: LiveState) { mutable.value = value }
    fun update(block: (LiveState) -> LiveState) { mutable.value = block(mutable.value) }

    fun addLine(source: String, translated: String, elapsedMs: Long) {
        val line = SubtitleLine(System.nanoTime(), source, translated)
        update { old ->
            old.copy(
                sourceText = source,
                translatedText = translated,
                processingMs = elapsedMs,
                status = "تعمل الترجمة",
                lines = (old.lines + line).takeLast(80)
            )
        }
    }
}
