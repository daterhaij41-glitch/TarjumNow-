pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "TarjumNow"
include(":app", ":whisperlib")
project(":whisperlib").projectDir = file("whisper.cpp/examples/whisper.android/lib")
